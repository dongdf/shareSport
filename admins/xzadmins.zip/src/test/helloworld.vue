<template>
    <div>welcome</div>
</template>

<script>
    export default {
        name: "helloworld"
    }
</script>

<style scoped>

</style>